def año_bisiesto():
  año: int = int(input("Introduce un año a ver si es año bisiesto "))

  if(año % 4 == 0 and (año % 100 != 0 or año % 400 == 0)):
      print(f"{año} es bisiesto!")
      
  else:
      print(f"{año} NO es bisiesto!")

año_bisiesto()