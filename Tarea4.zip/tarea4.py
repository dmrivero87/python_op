listaNumeros = range(1, 101)
listaOrdenada = sorted(listaNumeros, reverse=True)
for numeros in listaOrdenada:
    print(numeros)